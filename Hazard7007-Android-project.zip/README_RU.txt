Hazard 7007 — проект Android

Это исходный проект приложения (WebView), а не готовый APK.
Сайт из исходного ZIP помещён в app/src/main/assets/index.html.
Приложение открывает его локально, без обращения к сайту в интернете.

Как получить APK:
1. Откройте проект Hazard7007 в Android Studio на компьютере.
2. Дождитесь синхронизации Gradle.
3. Выберите Build → Build Bundle(s) / APK(s) → Build APK(s).
4. APK появится в app/build/outputs/apk/debug/app-debug.apk.

Требуется Android Studio с Android SDK. Если Android Studio попросит установить
Android SDK Platform 35 или Gradle-плагины, согласитесь.
